#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int Collatz (long int x, int count) {
  if (x == 1) {
    printf ("%d\n", count);
    return count;
  else if (x % 2 == 1)
    Collatz ((3 * x + 1) / 2, count + 2);
  else 
    Collatz (x / 2, ++count);
}

int main () {
  int i, f, aux = 0;
  //Ponteiros para o primeiro e ultimo nos
  Node* head = NULL; Node* rear =  NULL;

  scanf ("d %d", &i, &f);

  for (int j = i; j <= f; j++) {
    // FORMA "2 + 4N", Detalhes no relatorio
    if (j >= 6 && (j - 2) % 4 == 0 && 2 * j <= f)
      push (&head, 2 * j, Collatz (j, 0), &rear, rear);

    //FORMA 4 + 8N OU 5 + 8N 
    else if (!isEmpty (&head) && (j == peek (&head) || aux)) {
      printf ("%d\n", peekStep (&head) + 1);
      if (aux || j == f) {
        pop (&head);
        aux = 0;
      }
      else
        aux = 1;
    }
    else 
      Collatz (j, 0);
  }
  return EXIT_SUCCESS;
}